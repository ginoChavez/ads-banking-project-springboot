INSERT INTO role(role_id, role_name) 
VALUES
	(1, 'Manager'),
	(2, 'Cashier'),
	(3, 'Customer');