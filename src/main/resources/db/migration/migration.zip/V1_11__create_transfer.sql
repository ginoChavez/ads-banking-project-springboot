CREATE TABLE transfer(
	transfer_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    number_account_origin VARCHAR(50) NOT NULL,
	number_account_destiny VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    date_registry DATE NOT NULL,
	PRIMARY KEY (transfer_id)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;