INSERT INTO role_claim(claim_type, claim_value, role_id) 
	VALUES
	('canAddPerson', 'true', 1),
	('canSavePerson', 'true', 1),
	('canAccessPersons', 'true', 1),
	('canAddAccount', 'true', 1),
	('canSaveAccount', 'true', 1),
	('canAccessAccounts', 'true', 1),
	('canAccessTransfers', 'true', 1),
	('canAccesPerson', 'true', 2),
	('canUpdatePerson', 'true', 2),
	('canUpdateAccount', 'true', 2),
	('canAccesAccount', 'true', 2),
	('canAccessTransfers', 'true', 2);