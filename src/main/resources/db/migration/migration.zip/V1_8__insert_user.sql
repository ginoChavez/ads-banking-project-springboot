INSERT INTO user(person_id, role_id, user_name, password) 
VALUES
	(1, 1, 'user1',  '$2a$11$6bVU6URKQ3DScJAjlUjlL.drz7Zotb.fzP5ZFFAWMp.TUB25to3nu'),
	(2, 2, 'user2', '$2a$11$vujsCJlGTFo.pn/JIK3rN.enG96xBahdwiVDOakalmH30ywXTCOd6');