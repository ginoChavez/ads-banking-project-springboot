INSERT INTO person(person_id, first_name, last_name, dni, address, phone, active) 
VALUES
(1, 'Juan', 'Pérez', '12387699', 'Jirón Camaná S/N', '997754545',  1),
(2, 'Carlos', 'Pérez', '98654321', 'Avenida del Aire 123', '976435344', 1),
(3, 'Alberto', 'Otero', '67564432', 'Las Gaviotas, Calle 001', '943232333', 1);