INSERT INTO bank_account(bank_account_id, number, balance, locked, person_id) 
VALUES
(1, '123-456-001', 3500, 0, 1),
(2, '123-456-002', 4800, 0, 1),
(3, '123-456-003', 5500, 0, 2),
(4, '123-456-004', 6800, 0, 3);